package com.smartbackrest;

public enum MealSize {
    SMALL, MEDIUM, LARGE, NOT_SURE, NONE
}
