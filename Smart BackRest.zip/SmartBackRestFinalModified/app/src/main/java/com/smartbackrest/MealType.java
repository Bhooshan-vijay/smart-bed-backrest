package com.smartbackrest;

public enum MealType {
    SOLID, LIQUID, SEMI_SOLID, NOT_SURE
}
